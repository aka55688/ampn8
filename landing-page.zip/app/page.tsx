"use client"

import LandingPage from "../landing-page"

export default function SyntheticV0PageForDeployment() {
  return <LandingPage />
}